<?php
$day = 'Monday';

if($day === 'Friday' || $day === 'Saturday'){
    echo 'Today is Holiday';
}else{
    echo 'Today is not Holiday';
}

echo '<br /><br>';

$number = '10';

if($number >= 5){
    echo 'This is true';
} else{
    echo 'This is not true';
}

?>